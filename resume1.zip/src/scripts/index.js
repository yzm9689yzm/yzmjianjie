﻿var $ = require("./common/libs/zepto-modules/zepto.js");

require("./common/libs/zepto-modules/event.js");
require("./common/libs/zepto-modules/touch.js");
require("./common/libs/zepto-modules/ajax.js");
var $1 = require("./common/libs/zepto-modules/jquery-1.11.3.js");

var Swiper1 = require('./common/libs/swiper/swiper.min.js');
var SwiperAni = require('./common/libs/swiper/swiper.animate1.0.2.min.js');
var IScroll = require('./common/libs/iscroll/iscroll.js');

$1(".swiper-container").show();
$1('#mainContainer').hide();

var swiper = new Swiper1('.swiper-container', {
        pagination: '.swiper-scrollbar',
        paginationType: 'progress',
        direction: 'horizontal',
        onInit:function(swiper){
        	SwiperAni.swiperAnimateCache(swiper);
        	SwiperAni.swiperAnimate(swiper);
        },
        onSlideChangeEnd:function(swiper){
        	SwiperAni.swiperAnimate(swiper);
        }
    });
mus()
$1('#music1').on('click',function() {
	mus()
});   
function mus(){
 var audio = document.getElementById('music'); 
 if(audio.paused){                 
     audio.play();//audio.play();// 播放 
     $1('#music1 img').css('-webkit-animation',"circle 1s infinite linear") 
 }
 else{
      audio.pause();// 暂停
      $1('#music1 img').css('-webkit-animation',"1s infinite linear")
 } 
}
function next1(){
	if($1('.next').show()){
		// $1('.next').css({right:0});
		// $1('.next').hide();
		$1('.next').stop().animate({right:0},1000,function(){
			$1('.next').stop().animate({opcity:0},1000);
			$1('.next').css({right:-50,opcity:1});
		})
	}
}
function float(){
	$1('.box_header_left span').stop().animate({
		top:10+'px'
	}, 1000,function(){
		$1('.box_header_left span').stop().animate({
			top:25+'px'
		},1000)
	})
}
var timer = setInterval(next1,2000);
var timer1 = setInterval(float,2000);

var myScroll;
$1("#enter").click(function() {
	$1(".swiper-container").hide();
	$1('#mainContainer').show();

	$1.post('http://localhost:8000/project',function(data){
		var html = "";
		$1('#mainContainer').removeClass('mainContainer1')
		html+="<li class='"+data[0].class+"iconfont'><br><span>"+data[0].title+"</span></li>"
		for(var i = 1;i<data.length-1;i++){
			html += "<li><span class='span1'>"+data[i].time+"</span><b class='iconfont icon-iconfontdian1'></b><span class='span2'>"+data[i].category+"</span></li>";
		}
		html+="<p><img src='../images/pic9.png'</p>";
		$1("#scroller ul").html(html);
		scroll2()
	})
	
	myScroll = new IScroll('#wrapper', { mouseWheel: true });
	document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);
$1('.next').hide();
clearInterval(timer);
});
$1("#footer .button").on('tap',function(){
	var targetApi = $(this).attr('id');
	console.log(targetApi);
	$1.post('http://localhost:8000/'+targetApi,function(data){
		var html = "";
		if (targetApi=='project') {
			$1('#header').html('个人经历');
			$1('#mainContainer').removeClass('mainContainer1');
			$1('.work_text').remove();
			html+="<li class='"+data[0].class+"iconfont'><br><span>"+data[0].title+"</span></li>"
			for(var i = 1;i<data.length-1;i++){
				html += "<li><span class='span1'>"+data[i].time+"</span><b class='iconfont icon-iconfontdian1'></b><span class='span2'>"+data[i].category+"</span></li>";
			}
			html+="<p><img src='../images/pic9.png'</p>";
			$1("#scroller ul").html(html);
			scroll2()
		}else if(targetApi=='skill'){
			$1('#header').html('兴趣爱好');
			$1('#mainContainer').removeClass('mainContainer1');
			$1('.work_text').remove();
			html+="<li class='"+data[0].class+"iconfont'><br><span>"+data[0].title+"</span></li>"
			for(var i = 1;i<data.length-1;i++){
				html += "<li class='li4'><span class='span3'><img src='"+data[i].category+"'></span><span>"+data[i].text+"</span></li>";
			}
			$1("#scroller ul").html(html);
			scroll2()
		}else if(targetApi=='work'){
			$1('#header').html('作品展示');
			$1('#mainContainer').addClass('mainContainer1')
			$1('.mainContainer1').append("<div class='work_text'></div>")
			$1('.work_text').html(data[1].text);
			
			for(var i = 1;i<data.length;i++){
				html += "<li class='li5'><img src='"+data[i].image+"'></li>";
			}
			$1("#scroller ul").html(html);
			scroll1()

		}else if(targetApi=='mine'){
			$1('#header').html('联系方式');
			$1('#mainContainer').removeClass('mainContainer1');
			$1('.work_text').remove();
			html+="<div class='div1'><img src='"+data[1].image+"'></div><div class='div2 iconfont icon-dianhua'>"+data[2].dianhua+"</div><div class='div3 iconfont icon-QQ'>"+data[3].QQ+"</div><div class='div4'>"+data[4].tit+"</div>";
			$1("#scroller ul").html(html);
			scroll2();
		}

		$("#scroller .li5").on('tap',function(){
			console.log(1)
			var index = $(this).index();
			$1('.work_text').html(data[index+1].text)
		})
	    
	})

})
function scroll1(){
	myScroll1 = new IScroll('#wrapper', { eventPassthrough: true, scrollX: true, scrollY: false, preventDefault: false });
}
function scroll2(){
	myScroll = new IScroll('#wrapper', { mouseWheel: true });
    document.addEventListener('touchmove', function(e) { e.preventDefault(); }, false);
	myScroll.scrollTo(0,0);
	myScroll.refresh();
}


// $1("#footer .button").tap(function(){
// 	console.log(1)
// 	var targetApi = $(this).attr('id');
// 	$1.post('http://localhost:8000/'+targetApi,function(data){
// 		var html = "";
// 		for(var i = 0;i<data.length;i++){
// 			html += "<li>"+data[i].category+"</li>";
// 		}
// 		$1("#scroller ul").html(html);
// 		myScroll.scrollTop(0,0);
// 		myScroll.refresh();
// 	})
// })

// $1('.swiper-slide1_foot_p1').addClass('animate bouncelnDown')

// var mySwiper = new Swiper2('.swiper-container',{
//       //其他设置
//         container : '.swiper-scrollbar'
//   });  

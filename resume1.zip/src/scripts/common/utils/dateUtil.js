var DateUtil = {
	getDate:function(){
		return new Date().toLocaleDateString();
	}
}

//我们需要接口暴露
module.exports = DateUtil;

console.log("DateUtil is import");
# changelog

## 1.0.1

* Zepto link and version in README

## 1.0.0

* second release (zepto@28.09.2016 - 1.2.0 with changes)
* remove es6 modules (useless)

## 0.0.0

* first release (zepto@01.01.2016 - 1.1.6 with changes)
* modules: CommonJS (and ES6)

var gulp = require('gulp');

var webserver = require('gulp-webserver');

var url = require('url');

var fs = require('fs');//fs指的是filesystem

var sass = require('gulp-sass');

var webpack = require('gulp-webpack');

var named = require('vinyl-named');
//cnmp install vinyl-named --save-dav

var uglify = require('gulp-uglify');

var minifyCss = require('gulp-minify-css');

var rev= require('gulp-rev');

var revCollector = require('gulp-rev-collector');

var watch = require('gulp-watch');

var sequence = require('gulp-watch-sequence');

gulp.task('copy-index',function(){
	return gulp.src('./src/index.html')
	.pipe(gulp.dest('./www'));
});

gulp.task('copy-images',function(){
	return gulp.src('./src/images/*')
	.pipe(gulp.dest('./www/images/'));
});

gulp.task('webserver',function(){
	gulp.src('./www')
	.pipe(webserver({
		liverrload:true,
		// directoryListing:true,
		open:true,

		middleware:function(req,res,next){
			//获取浏览器中的url，将url进行解析
			var urlObj = url.parse(req.url,true),//parse解析
			method = req.method;
			//如果url里面输入了/shill.php,/project.php或者是/work，
			//那么我们就可以查找到urlObj.pathname为/shill.php,/project.php或者是/work，
			//然后我们就可通过这个变活的url地址获取对应的json文件
			
			switch(urlObj.pathname){
				case '/skill':
					//Content-Type可以指定返回的文件的格式类型
					res.setHeader('Content-Type','application/json');
					fs.readFile('./mock/skill.json','utf-8',function(err,data){
						res.end(data);
					})
				return;

				case '/project':
					//Content-Type可以指定返回的文件的格式类型
					res.setHeader('Content-Type','application/json');
					fs.readFile('./mock/project.json','utf-8',function(err,data){
						res.end(data);
					})
				return;

				case '/work':
					//Content-Type可以指定返回的文件的格式类型
					res.setHeader('Content-Type','application/json');
					fs.readFile('./mock/work.json','utf-8',function(err,data){
						res.end(data);
					})
				return;

				case '/mine':
					//Content-Type可以指定返回的文件的格式类型
					res.setHeader('Content-Type','application/json');
					fs.readFile('./mock/mine.json','utf-8',function(err,data){
						res.end(data);
					})
				return;
			}
			// console.log(urlObj);

			next(); //next是实现的循环
		}//end middleware

	}));//end gulp
});

gulp.task('sass',function(){
	return gulp.src('./src/styles/index.scss')
	.pipe(sass())
	.pipe(minifyCss()) //css压缩
	.pipe(gulp.dest('./www/css'));
});

gulp.task('packjs',function(){
	return gulp.src('./src/scripts/index.js')
	.pipe(named())
	.pipe(webpack())
	.pipe(uglify()) //js丑化压缩
	.pipe(gulp.dest('./www/js'));
})

var cssDistFiles = ['./www/css/index.css'];
var jsDistFiles = ['./www/js/index.js'];

gulp.task('verCss',function(){
	return gulp.src(cssDistFiles)
	.pipe(rev())
	.pipe(gulp.dest('./www/css'))
	.pipe(rev.manifest())
	.pipe(gulp.dest('./www/ver/css'));
});

gulp.task('verJs',function(){
	return gulp.src(jsDistFiles)
	.pipe(rev())
	.pipe(gulp.dest('./www/js'))
	.pipe(rev.manifest())
	.pipe(gulp.dest('./www/ver/js'));
});
 
//文件的字符串操作
gulp.task('html',function(){
	gulp.src(['./www/ver/**/*.json','./www/*.html'])
	.pipe(revCollector({
		replaceReved:true
	}))
	.pipe(gulp.dest('./www'))
})

gulp.task('watch',function(){
	gulp.watch('./src/index.html',['copy-index']);

	var queue = sequence(300);
	watch('./src/scripts/**',{
		name:"JS",
		emitOnGlob:false
	},queue.getHandler('packjs','verJs','html'));

	watch('./src/styles/**',{
		name:"CSS",
		emitOnGlob:false
	},queue.getHandler('sass','verCss','html'));
});

gulp.task('default',['webserver','watch']);